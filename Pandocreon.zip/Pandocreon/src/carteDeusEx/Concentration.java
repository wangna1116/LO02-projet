package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Concentration extends DeusEx {
	//constructeur
	public  Concentration(){
		this.nom="Concentration";
		this.origine = "N��ant";
	}
	
	//Vous r��cup��rez un des Guides Spirituels pos��s devant une autre Divinit�� et 
	//le placez devant vous avec les Croyants qui y sont attach��s.
	 public void utiliserCapacite(Joueur j){
		  
	  }
}
