package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;

public class Col��reDivineJour extends DeusEx {
	//constructeur
	public Col��reDivineJour(){
		this.nom="Col��reDivineJour";
		this.origine = "Jour";
	}
			
	//D��truit une carte Guide Spirituel d'Origine Nuit ou N��ant, 
	//dont la capacit�� sp��ciale n'a pas effet. 
	//Les Croyants attach��s reviennent au centre de la table.
	 public void utiliserCapacite(Joueur j){
		  
	  }
}
