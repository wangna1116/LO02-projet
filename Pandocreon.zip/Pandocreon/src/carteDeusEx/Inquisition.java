package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Inquisition extends DeusEx{
	//contructeur
    public Inquisition(){
   	 this.nom="Inquisition";
   	 this.origine = "";
    }
    
    //Choisissez un des Guides Spirituels d'un autre joueur, et l'un des votres. 
    //Lancez le d�� de Cosmogonie. Sur Jour, le Guide adverse est sacrifi��, 
    //sur Nuit le votre est sacrifi��, sur N��ant rien ne se passe. Les
    public void utiliserCapacite(Joueur j){
  	  
    }
}
