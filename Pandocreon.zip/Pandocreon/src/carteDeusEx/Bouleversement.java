package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Bouleversement extends DeusEx{
	
	  //constructeur
	public  Bouleversement(){
		this.nom="bouleversement";
		this.origine = "";
	}
	
	  //Relancez le d�� de Cosmogonie. Le tour de jeu se terminera normalement, 
	  //mais sous la nouvelle influence.
	public void utiliserCapacite(Joueur j){
		
	}
}
