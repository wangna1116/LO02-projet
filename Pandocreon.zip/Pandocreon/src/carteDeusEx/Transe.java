package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Transe extends DeusEx{
	//contructeur
    public Transe(){
   	 this.nom="Transe";
   	 this.origine = "";
    }
    
    //Permet de r��cup��rer les effets b��n��fiques d'une carte d'Action 
    //pos��e par une autre Divinit��. S'il s'agit d'une carte Croyants 
    //ou Guide Spirituel, vous posez la carte devant vous.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
