package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class OrdreC��leste extends DeusEx{
	  //contructeur
	public OrdreC��leste(){
		this.nom="OrdreC��leste";
		this.origine = "Jour";
	}
	
	  //Vous r��cup��rez un des Guides Spirituels pos��s devant une autre Divinit�� 
      //et le placez devant vous avec les Croyants qui y sont attach��s.
	public void utiliserCapacite(Joueur j){
		
	}
}
