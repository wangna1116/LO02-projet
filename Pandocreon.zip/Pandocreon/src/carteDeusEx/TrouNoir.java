package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class TrouNoir extends DeusEx{
	//contructeur
    public TrouNoir(){
   	 this.nom="TrouNoir";
   	 this.origine = "N��ant";
    }
    
    //Aucun autre joueur ne gagne de points d'Action durant ce tour.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
