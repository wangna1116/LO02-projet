package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class InfluenceN��ant extends DeusEx{
	//contructeur
    public InfluenceN��ant(){
   	 this.nom="InfluenceN��ant";
   	 this.origine = "";
    }
    
    //Annule la capacit�� sp��ciale d'une carte d'Action d'Origine Jour ou Nuit.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
