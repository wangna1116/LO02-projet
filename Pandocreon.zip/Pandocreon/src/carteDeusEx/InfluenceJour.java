package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class InfluenceJour extends DeusEx{
	//contructeur
    public InfluenceJour(){
   	 this.nom="InfluenceJour";
   	 this.origine = "";
    }
    
    //Annule la capacit�� sp��ciale d'une carte d'Action d'Origine Nuit ou N��ant.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
