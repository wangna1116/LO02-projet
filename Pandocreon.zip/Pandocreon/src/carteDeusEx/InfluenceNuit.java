package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class InfluenceNuit extends DeusEx{
	//contructeur
    public InfluenceNuit(){
   	 this.nom="InfluenceNuit";
   	 this.origine = "";
    }
    
    //Annule la capacit�� sp��ciale d'une carte d'Action d'Origine Jour ou N��ant.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
