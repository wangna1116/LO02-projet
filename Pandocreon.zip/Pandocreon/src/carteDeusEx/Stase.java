package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Stase extends DeusEx{
	//contructeur
    public Stase(){
   	 this.nom="Stase";
   	 this.origine = "Jour";
    }
    
    //Prot��ge un Guide Spirituel et ses Croyants jusqu'�� ce que 
    //cette carte soit annul��e ou jusqu'�� la prochaine tentative d'Apocalypse.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
