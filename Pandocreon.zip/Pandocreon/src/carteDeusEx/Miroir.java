package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Miroir extends DeusEx{
	//contructeur
    public Miroir(){
   	 this.nom="Miroir";
   	 this.origine = "";
    }
    
    //Retourne les effets d'une carte d'Action sur la Divinit�� qui l'a pos��e.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
