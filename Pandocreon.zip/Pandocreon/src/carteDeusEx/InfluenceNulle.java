package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class InfluenceNulle extends DeusEx{
	//contructeur
    public InfluenceNulle(){
   	 this.nom="InfluenceNulle";
   	 this.origine = "";
    }
    
    //Annule la capacit�� sp��ciale d'une autre carte d'Action.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
