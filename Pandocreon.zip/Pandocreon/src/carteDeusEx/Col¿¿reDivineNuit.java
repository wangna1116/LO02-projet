package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;

public class Col��reDivineNuit extends DeusEx {
	//constructeur
	public Col��reDivineNuit(){
		this.nom="Col��reDivine";
		this.origine = "Nuit";
	}
			
	//D��truit une carte Guide Spirituel d'Origine Jour ou N��ant, 
	//dont la capacit�� sp��ciale n'a pas effet. 
	//Les Croyants attach��s reviennent au centre de la table.
	 public void utiliserCapacite(Joueur j){
		  
	  }

}
