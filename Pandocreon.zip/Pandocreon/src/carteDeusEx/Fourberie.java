package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Fourberie extends DeusEx{
	//contructeur
    public Fourberie(){
   	 this.nom="Fourberie";
   	 this.origine = "Nuit";
    }
    
    //Sacrifiez 2 cartes Croyants d'une autre Divinit��. 
    //Les capacit��s sp��ciales ne sont pas jou��es.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
