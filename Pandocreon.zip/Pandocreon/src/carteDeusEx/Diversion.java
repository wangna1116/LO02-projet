package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Diversion extends DeusEx{
	//constructeur
	public Diversion(){
	  this.nom="Diversion";
	  this.origine = "Nuit";
	}
	
	//Prenez 3 cartes dans la main d'un autre joueur et incluez-les �� votre main.
	 public void utiliserCapacite(Joueur j){
		  
	  }
}
