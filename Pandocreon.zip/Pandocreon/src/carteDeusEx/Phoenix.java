package carteDeusEx;

import control.Joueur;
import carteAction.DeusEx;


public class Phoenix extends DeusEx{
	//contructeur
    public Phoenix(){
   	 this.nom="Phoenix";
   	 this.origine = "N��ant";
    }
    
    //Permet de b��n��ficier de la capacit�� sp��ciale de l'un de vos Croyants ou 
    //Guides Spirituels sans sacrifier la carte.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
