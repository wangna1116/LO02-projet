package control;

public interface Strategie {
   public abstract int choisirAction(int nombreCartesEnMain);
}
