package control;
import divinite.Divinite;
import carteAction.Apocalypse;
import carteAction.CarteAction;
import carteAction.CartePile;
import carteAction.CarteTable;
import carteAction.Croyant;
import carteAction.DeusEx;
import carteAction.GuideSpirituel;

import java.util.*;

public class Joueur {
	private int numeroJoueur;
	private int pointActionJour;
	private int pointActionNuit;
	private int pointActionN��ant;
	private Divinite divinite;
	  //une List pour placer les carte en main qui n'est que visible pour ce Joueur 
	private List carteEnMain;
	  //Les cartes Guide Spirituel dans l'espace joueur, qui est attach�� avec les cartes croyant(carteCroyantEnjeu)
	private List carteGsEnjeu;
	  //Les cartes Croyant dans l'espace joueur, qui est compt�� dans ses point de pri��re
	private List carteCroyantEnjeu;
	  //Point de pri��re du Joueur
	public int puissanceJoueur;
	  //Carte que le joueur en train de poser
	private CarteAction CartePose;
	
	  //le constructeur
	public  Joueur(int numero){
		this.numeroJoueur=numero;
		this.carteEnMain=new ArrayList();
		this.carteGsEnjeu = new ArrayList();
		this.carteCroyantEnjeu = new ArrayList();
		this.pointActionJour=0;
		this.pointActionNuit=0;
		this.pointActionN��ant=0;
	}
	
	  //piocher divinite au debut du jeu
	public void piocherDivinite(Divinite divinitePioche){
		this.divinite=divinitePioche;
		System.out.println("Joueur"+this.numeroJoueur+" pioche divinite:"+this.divinite.getNom());
	}
	
	  //get divinite
	public Divinite getDivinite() {
		return divinite;
	}
	
	/**
	 * �غ�������
	 */
	  //D��fausser les cartes choisis par Joueur
	public void defausserCarte(){
		boolean end = false;
		  //choisir le numero du carte vous voulez defausser
		System.out.println("Saisir le numero du carte vous voulez defausser!");
		Scanner input=new Scanner(System.in);
		int i=input.nextInt();
		do{
			if(i < carteEnMain.size()&&i>=0){
				carteEnMain.remove(i);
			}else{
				System.out.println("Wrong number");
				continue;
			}
			System.out.println("Si vous voulez arr��ter de d��fausser cartes, saisissez 'end'");
			end = input.next().equals("end");
			}while(end == false);
	}
	
	/**
	 * ���������Լ��غ�������
	 * �Ѳ��Կ������ƣ���������
	 * �ƶ��м���ǰ14����
	 */
	  //piocher carteAction
	public void piocherCarte(Partie partie){
		CartePile cp = partie.getCarteEnJeu();
		List l = cp.getCartes();
		if(carteEnMain.size() == 7){
			System.out.println("Vous ne pouvez pas piocher les cartes");
		}else{
			while(carteEnMain.size() < 7){
				carteEnMain.add(l.get(0));
				l.remove(0);
			}
		}
		
		cp.setCartes(l);
		partie.setCarteEnJeu(cp);
		  //Afficher les cartes en main obtenu
		Iterator it = carteEnMain.iterator();
		System.out.println("Les cartes en main de Joueur " + getNumeroJoueur() + " est:");
		while(it.hasNext()){ 
	 		CarteAction ca = (CarteAction)it.next(); 
	 		System.out.println("CarteEnMain : " + ca.getNom() );
	 	}
		
	}
	
	/**
	 * �غ��У�������
	 * ʹ��Apocalypse��utiliserApocalypse
	 * ʹ��DeusEx��utiliserDeusEx
	 * ʹ��Croyant
	 * ʹ��GuideSpirituel
	 * ����Croyant:poserCroyant
	 * ����Cryant��utiliserGuideSpirituel
	 */
	public void utiliserCarte(Partie partie){
		Iterator it = carteEnMain.iterator();
		System.out.println("Les cartes en main de Joueur " + getNumeroJoueur() + " est:");
		while(it.hasNext()){ 
	 		CarteAction ca = (CarteAction)it.next(); 
	 		System.out.println("CarteEnMain : " + ca.getNom() );
	 	}
		boolean endTour = false;
		while(!endTour){
			System.out.println("Vous avez " + getPointActionJour() + " point action Jour");
			System.out.println("Vous avez " + getPointActionNuit() + " point action Nuit");
			System.out.println("Vous avez " + getPointActionN��ant() + " point action N��ant");
			System.out.println("Saisir 0 pour terminer ou 1 pour continuer");
			Scanner sc = new Scanner(System.in);
			int i = -1;
			int d = -1;
			i=sc.nextInt();
			if(i == 0){
				endTour = true;
			}else if(i == 1){
				boolean FLAG = false;
				while(!FLAG) {
					try{
						System.out.println("Choisir une carte action et saisir son numero dans votre carte en main");
						d = sc.nextInt();
						if(d >= 0 && d < carteEnMain.size()) {
							FLAG = true;
						}else {
							System.out.println("Le num��ro de carte n'est pas compris dans votre carte en main");
							FLAG = false;
						}
					}catch(InputMismatchException e) {
						System.out.println("Erreur");
						sc.next();
						FLAG = false;
					}
				}
				CarteAction ca = (CarteAction)carteEnMain.get(d);
				
				//V��rifier si le joueur a des points d'action suffisant
				//Diminuer Point d'action
				switch(ca.getOrigine()) {
				case "Jour":
					if(this.pointActionJour >= 1) {
						this.pointActionJour -= 1;
					}else {
						System.out.println("Vous n'avez pas de point d'action Jour");
						continue;
					}
					break;
				case "Nuit":
					if(this.pointActionNuit >= 1) {
						this.pointActionN��ant -= 1;
					}else{
						System.out.println("Vous n'avez pas de point d'action Nuit");
						continue;
					}
					break;
				
				case "N��ant":
					if(this.pointActionN��ant >= 1) {
						this.pointActionN��ant -= 1;
					}else {
						System.out.println("Vous n'avez pas de point d'action N��ant");
						continue;
					}
					break;
				case "":
					break;
				default :
					break;
				}
				//Chercher le type de carte action et d��cider quelle m��thode
				switch(ca.getType()) {
				case "Croyant":
					Croyant cc = (Croyant)ca;
					System.out.println("'sacrifier' ou 'poser'!");
					Scanner sc1 = new Scanner(System.in);
					String input = sc1.next();
					if(input.equals("sacrifier")){
						utiliserCroyant(cc);
					}else if(input.equals("poser")){
						poserCroyant(cc);
					}

					break;
				case "GuideSpirituel":
					GuideSpirituel guide = (GuideSpirituel)ca;
					System.out.println("'sacrifier' ou 'utiliser'!");
					Scanner sc2 = new Scanner(System.in);
					String input2 = sc2.next();
					if(input2.equals("sacrifier")){
						utiliserGuideSpirituel(guide);
					}else if(input2.equals("utiliser")){
						poserGuideSpirituel(guide);
					}
					break;
				case "DeusEx":
					DeusEx de = (DeusEx)ca;
					utiliserDeusEx(de);
					break;
				case "Apocalypse":
					Apocalypse ap = (Apocalypse)ca;
					utiliserApocalypse(ap,partie);
					break;
				}
				//Supprimer la carte action en main
				carteEnMain.remove(i);
			}
		}
		
	}
	
	/**
	 * joueurʹ��DeusEx
	 */
	//Joueur sacrifie les cartes Guide Spirituel ou Carte Croyant
	public void utiliserDeusEx(DeusEx deusEx){
		deusEx.utiliserCapacite(this);
	}
	
	/**
	 * joueurʹ��croyant
	 */
	public void utiliserCroyant(Croyant croyant){
		croyant.utiliserCapacite(this);
	}
	
	/**
	 * joueurʹ��guideSpirituel
	 */
	public void utiliserGuideSpirituel(GuideSpirituel guide){
		guide.utiliserCapacite(this);
	}
	
	/**
	 * ʹ��Apocalypse
	 */
	public void utiliserApocalypse(Apocalypse apocalypse,Partie partie){
		apocalypse.utiliserCapacite(partie);
	}
	
	/**
	 * ��croyant������������
	 */
	public void poserCroyant(Croyant croyant){
		CarteTable.getCarteTable().ajouterCroyant(croyant);
		System.out.println("Vous avez posez la carte:" + croyant.getNom() + " dans l'espace Table");
		CarteTable.getCarteTable().printCarteTable();
	}
	
	/**
	 * ��guide spirituel����croyant
	 */
	public void poserGuideSpirituel(GuideSpirituel guide){
		int size = CarteTable.getCarteTable().getCroyantEnTable().size();
		int priere = guide.getNombreCroyant();
		if(priere <= size){
			for(int i = 0; i < priere ; i++){
				System.out.println("Saisir le num��ro de carte en table vous voulez attacher");
				Scanner sc = new Scanner(System.in);
				Croyant cr = (Croyant)CarteTable.getCarteTable().getCroyantEnTable().get(sc.nextInt());
				this.carteCroyantEnjeu.add(cr);
				CarteTable.getCarteTable().supprimerCroyant(cr);
			}
			this.carteGsEnjeu.add(guide);
		}else{
			System.out.println("Il n'y a pas assez de carte croyant pour attacher");
		}
	}
	
	  //choisir une action
	public void Action(int numeroDuAction,Partie partie){
		switch (numeroDuAction) {
		case 0:
			defausserCarte();
			break;
		case 1:
			piocherCarte(partie);
			break;
		case 2:
			utiliserCarte(partie);
			break;
		default:
			//
			break;
		}
	}
	
	  //memorizer la carte croyant rattach�� avec carte guide spirituel.
	public int calculatorPuissance(){
		int puissance = 0;
		Croyant cy;
		int size = carteCroyantEnjeu.size();
		for(int ind = 0 ; ind <size ; ind++){
			cy = (Croyant)carteCroyantEnjeu.get(ind);
			puissance += cy.getNombrePuissance();
		}
		return puissance;
	}
	
	  //test si les joueurs sont creer?
	public void test(){
		System.out.print(this.numeroJoueur);
	}
	
	
	  //Getters & Setters
	public void addCarteGsEspace(GuideSpirituel gs){
		carteGsEnjeu.add(gs);
	}

	public int getNumeroJoueur() {
		return numeroJoueur;
	}

	public void setNumeroJoueur(int numeroJoueur) {
		this.numeroJoueur = numeroJoueur;
	}

	public int getPointActionJour() {
		return pointActionJour;
	}

	public void setPointActionJour(int pointActionJour) {
		this.pointActionJour = pointActionJour;
	}

	public int getPointActionNuit() {
		return pointActionNuit;
	}

	public void setPointActionNuit(int pointActionNuit) {
		this.pointActionNuit = pointActionNuit;
	}

	public int getPointActionN��ant() {
		return pointActionN��ant;
	}

	public void setPointActionN��ant(int pointActionN��ant) {
		this.pointActionN��ant = pointActionN��ant;
	}

	public List getCarteEnMain() {
		return carteEnMain;
	}

	public void setCarteEnMain(List carteEnMain) {
		this.carteEnMain = carteEnMain;
	}

	public List getCarteGsEnjeu() {
		return carteGsEnjeu;
	}

	public void setCarteGsEnjeu(List carteGsEnjeu) {
		this.carteGsEnjeu = carteGsEnjeu;
	}

	public List getCarteCroyantEnjeu() {
		return carteCroyantEnjeu;
	}

	public void setCarteCroyantEnjeu(List carteCroyantEnjeu) {
		this.carteCroyantEnjeu = carteCroyantEnjeu;
	}

	public int getPuissanceJoueur() {
		return puissanceJoueur;
	}

	public void setPuissanceJoueur(int puissanceJoueur) {
		this.puissanceJoueur = puissanceJoueur;
	}

	public CarteAction getCartePose() {
		return CartePose;
	}

	public void setCartePose(CarteAction cartePose) {
		CartePose = cartePose;
	}

	public void setDivinite(Divinite divinite) {
		this.divinite = divinite;
	}
	
	
	


}
