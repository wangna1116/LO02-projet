package control;

public class JoueurPhysique extends Joueur{
	 //constructeur
	  public JoueurPhysique(int numero){
		  super(numero);
	  }
	  //	 public int tourDuJoueur(){
	  //calculate le nombre des cartes en main
	  //System.out.println("Vos cartes en main sont:");
  //	   getCarteEnMain
  //	  return i ;
   // }
}
