package control;

public interface TerminerJeu {

}
