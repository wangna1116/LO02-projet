package control;
import java.util.List;
import java.util.Random;


public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Partie tour=new Partie();
		//tour.creerJoueur();
		 Random r=new Random();
		 int resultat = r.nextInt(2);
		 int resultatDe=(int)Math.floor(resultat);
		 System.out.println(resultatDe);
		
		
		
    }

}
