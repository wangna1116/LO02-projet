package divinite;

import java.util.List;
import java.util.Scanner;
import control.Joueur;
import control.Partie;

public class Gorpa extends Divinite {
	//constructeur
	  public Gorpa(){
		  this.setNom("Gorpa");
		  this.setDiviniteOrigine("Cr��puscule");
		  this.setDiviniteDogme("HumainSymbolesChaos");
	  }
	  
	  //Puet r��cup��rer les points d'Action d'une autre Divinit�� en plus des siens. 
	  //Et l'autre Divinit�� ne recoit aucun point d'Action ce tour-ci.
	  public void capaciteDivinite(Partie partie){
		  boolean capacite = true;
		  //Si true, cela veut dire que le joueur n'a pas utilis�� son capacit��
		  if(capacite == true){
			  List lj = partie.getJoueurs();
			  Joueur j2 = (Joueur)lj.get(0);  //Joueur qui est choisir 
			  Joueur j1 = (Joueur)lj.get(0);  //Le joueur qui a ce capacit��
			  //Le joueur entre le num��ro de joueur qu'il veux utiliser son capacit��
			  System.out.println("Choisir un joueur");
			  Scanner sc = new Scanner(System.in);
			  int numJoueur = sc.nextInt();
			  //Un boucle forEach pour chercher le joueur choisi selon son num��roJoueur
			  for(Object obj:lj){  
					Joueur j = (Joueur)obj;
					//Si le num��ro de ce joueur trouv�� est ��gale �� l'entier saisi,on le d��fini comme j2
					if(j.getNumeroJoueur() == numJoueur){
						j2 = j;
						break;
					}
				}
			  //Un boucle pour trouver le joueur qui a ce divinit��(qui utilise ce capacit��)
			  for(Object obj:lj){  
					Joueur j = (Joueur)obj;
					//Si le divinit�� de ce joueur trouv�� est le m��me avec ce divinit��,on le d��fini comme j1
					if(j.getDivinite().getNom() == "Gorpa"){
						j1 = j;
						break;
					}
				}
			  int point2 = j2.getPointActionJour() + j2.getPointActionNuit() + j2.getPointActionN��ant();
			  int point1 = j1.getPointActionJour() + j1.getPointActionNuit() + j1.getPointActionN��ant();
			  if(point1 < point2){
				  j1.setPointActionJour(j2.getPointActionJour());
				  j1.setPointActionNuit(j2.getPointActionNuit());
				  j1.setPointActionN��ant(j2.getPointActionN��ant());
				  j2.setPointActionJour(0);
				  j2.setPointActionNuit(0);
				  j2.setPointActionN��ant(0);
				  //la capacit�� de divinit�� n'��tre utilis�� qu'une seul fois
				  capacite = false;
				  System.out.println("joueur num��ro" + j1.getNumeroJoueur() + "r��cup��re les points action de joueur num��ro" + j2.getNumeroJoueur());
				  System.out.println("joueur num��ro" + j2.getNumeroJoueur() + "perd ses point d'action");
			  }else{
				  System.out.println("joueur num��ro" + j1.getNumeroJoueur() + "ne peux pas utiliser maintenant");
			  }
		  }
		  
	  }
	  
	  
}
