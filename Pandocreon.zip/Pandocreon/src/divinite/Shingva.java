package divinite;

import control.Partie;
import carteAction.GuideSpirituel;

public class Shingva extends Divinite {
	//constructeur
	  public Shingva(){
		  this.setNom("Shingva");
		  this.setDiviniteOrigine("Aube");
		  this.setDiviniteDogme("HumainMystiqueChaos");
	  }
	  
	  
	  //Pour imposer le sacrifice d'un Guide Spirituel ayant le Dogme Symboles ou Nature;
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
}
