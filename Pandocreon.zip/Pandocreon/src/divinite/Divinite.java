package divinite;

import control.Partie;

public class Divinite {
  private String diviniteDogme;
  private String nom;
  private String diviniteOrigine;
  private String diviniteCapacite;
  
  public void capaciteDivinite(Partie partie){
	  
  }
  
public String getDiviniteDogme() {
	return diviniteDogme;
}
public void setDiviniteDogme(String diviniteDogme) {
	this.diviniteDogme = diviniteDogme;
}

public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}

public String getDiviniteOrigine() {
	return diviniteOrigine;
}
public void setDiviniteOrigine(String diviniteOrigine) {
	this.diviniteOrigine = diviniteOrigine;
}
  
 
}