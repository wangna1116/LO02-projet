package divinite;

import java.util.List;
import java.util.Scanner;

import control.Joueur;
import control.Partie;

import carteAction.Apocalypse;
import carteAction.CarteAction;


public class Killinstred extends Divinite {
	  //constructeur
	public Killinstred(){
		this.setNom("Killinstred");
		this.setDiviniteOrigine("Nuit");
		this.setDiviniteDogme("NatureMystiqueChaos");
	}
	
	  //Peut obliger un joueur �� poser une carte Apocalypse s'il en poss��de une.
	public void capaciteDivinite(Partie partie){
		boolean capacite=true;
		List lj = partie.getJoueurs();
		Joueur j1 = (Joueur)lj.get(0);
		  //choisir un joueur,en saisissant
		System.out.println("Choisir un joueur");
		Scanner sc = new Scanner(System.in);
		int numJoueur = sc.nextInt();
		  //Boucle forEach pour trouver le joueur saisi
		for(Object obj:lj){  
			Joueur j = (Joueur)obj;
			  //Si le num��ro de ce joueur trouv�� est ��gale �� l'entier saisi,on le d��fini comme j2
			if(j.getNumeroJoueur() == numJoueur){
				j1 = j;
				break;
			}
		}
		List l = j1.getCarteEnMain();
		int i = 0;
		  //D��cider si le joueur choisi a une carte Apocalypse
		boolean have = false;
		if(capacite == true){
			while(have == false){
				CarteAction ca = (CarteAction)l.get(i);
				if(ca.getType() == "Apocalypse"){
					have = true;
					break;
				}
				i++;
				  //!!!!!!��֪������д�Բ���
				if(have == true){
					System.out.println("joueur num��ro" + j1.getNumeroJoueur() + "doit utiliser sa carte Apocalypse");
					Apocalypse ap =(Apocalypse)l.get(i);
					j1.utiliserApocalypse(ap,partie);
					l.remove(i);
					j1.setCarteEnMain(l);
					  //la capacit�� de divinit�� n'��tre utilis�� qu'une seul fois
					capacite = false;
				}else{
					System.out.println("joueur num��ro" + j1.getNumeroJoueur() + "n'a pas une carte Apocalypse");
				}
			}
		}
	}
	
	
}
