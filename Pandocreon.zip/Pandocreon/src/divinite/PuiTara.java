package divinite;

import java.util.List;

import control.Joueur;
import control.Partie;


public class PuiTara extends Divinite {
	//constructeur
	  public PuiTara(){
		  this.setNom("Pui-Tara");
		  this.setDiviniteOrigine("Nuit");
		  this.setDiviniteDogme("NatureMystiqueSymbole");
		  
	  }
	  
	  //Puet d��tuire toutes les cartes de Croyants au centre de la table d'Origine Jour
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
}
