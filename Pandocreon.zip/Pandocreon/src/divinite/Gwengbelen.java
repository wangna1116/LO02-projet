package divinite;

import control.Partie;

public class Gwengbelen extends Divinite {
	//constructeur
	  public Gwengbelen(){
		  this.setNom("Gwengbelen");
		  this.setDiviniteOrigine("Aube");
		  this.setDiviniteDogme("HumainMystiqueSymboles");
	  }
	  
	  //R��cup��re autant de points d'Action suppl��mentaire d'Origine N��ant que le nombre de Guides Spirituels que la Divinit�� poss��de
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
}
