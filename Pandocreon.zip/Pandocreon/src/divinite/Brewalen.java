package divinite;

import control.Partie;


public class Brewalen extends Divinite {
	  
      //constructeur
	  public Brewalen(){
		  this.setNom("Brewalen");
		  this.setDiviniteOrigine("Jour");
		  this.setDiviniteDogme("NatureHumainChaos");
	  }
	  
	  //Peut emp��cher l'utilisation d'une carte Apocalypse. La carte est d��fauss��e;
	  
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
	  
}
