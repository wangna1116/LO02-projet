package divinite;

import control.Partie;


public class Yarstur extends Divinite {
	//constructeur
	  public Yarstur(){
		  this.setNom("Yarstur");
		  this.setDiviniteOrigine("Jour");
		  this.setDiviniteDogme("ChaosSymbolesMystique");
	  }
	  
	  //Peut d��tuire toutes les cartes de Croyants au centre de la table d'Origine N��ant
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }

}
