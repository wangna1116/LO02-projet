package divinite;


public class Drinded extends Divinite {
	//constructeur
	  public Drinded(){
		  this.setNom("Drinded");
		  this.setDiviniteOrigine("Jour");
		  this.setDiviniteDogme("NatureHumainSymboles");
	  }
	  
	  //Peut emp��cher le sacrifice d'un des Guides Spirituels de n'importe quel joueur
	  public void capaciteDrinded(){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
}
