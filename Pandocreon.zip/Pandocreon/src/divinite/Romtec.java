package divinite;

import control.Joueur;
import control.Partie;

public class Romtec extends Divinite {
	//constructeur
	  public Romtec(){
		  this.setNom("Romtec");
		  this.setDiviniteOrigine("Cr��puscule");
		  this.setDiviniteDogme("NatureHumainChaos");
	  }
	  
	  
	  //Peut emp��cher un joueur de cr��er un Guide Spirituel. La carte est d��fauss��e.
	  public void capaciteDivinite(Partie partie){
		  boolean capacite=true;
		  if(capacite == true){
			  
		  }
	  }
}
