package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Martyr extends GuideSpirituel{
	//contructeur
    public Martyr(){
   	 this.nom="Martyr";
   	 this.nombreCroyant = 2;
    }
    
    //Equivalent �� la pose d'une carte Apocalypse.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
