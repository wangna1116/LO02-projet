package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Asc��te extends GuideSpirituel {
	//contructeur
    public Asc��te(){
   	 this.nom="asc��te";
   	 this.nombreCroyant = 1;
   	 this.origine = "Nuit";
   	 this.dogme = "HumainSymboles";
    }
    
    //Sacrifie 2 cartes Croyants d'une Divinit�� ayant le Dogme Humain ou Symboles. 
    //Les capacit��s sp��ciales sont jou��es normalement.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
