package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Shaman extends GuideSpirituel{
	//contructeur
    public Shaman(){
   	 this.nom="Shaman";
   	 this.origine = "Nuit";
   	 this.dogme = "NatureSymboles";
   	 this.nombreCroyant = 3;
    }
    
    //Sacrifie tous les Croyants d'Origine N��ant d'une Divinit�� ayant le Dogme Humain. 
    //Les capacit��s sp��cials sont jou��es normalement.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
