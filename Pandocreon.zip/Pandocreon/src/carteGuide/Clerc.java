package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Clerc extends GuideSpirituel {
	//contructeur
    public Clerc(){
   	 this.nom="clerc";
   	 this.nombreCroyant = 2;
    }
    
    //Fait gagner un nombre de points d'Action ��gal au nombre de cartes de 
    //Croyants rattach��es. L'Origine des points d'Action est au choix du joueur.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
