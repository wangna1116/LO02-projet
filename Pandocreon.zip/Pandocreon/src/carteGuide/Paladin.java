package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Paladin extends GuideSpirituel{
	//contructeur
    public Paladin(){
   	 this.nom="Paladin";
   	 this.dogme = "HumainMystique";
   	 this.origine = "Jour";
   	 this.nombreCroyant = 3;
    }
    
    //Tous les Croyants, d'Origine Nuit ou N��ant et ayant le Dogme Nature, actuellement sur la table sont d��fauss��s.
    //Les capacit��s sp��ciales ne sont pas jou��es.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
