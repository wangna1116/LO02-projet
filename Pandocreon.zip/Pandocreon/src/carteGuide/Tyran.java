package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Tyran extends GuideSpirituel{
	//contructeur
    public Tyran(){
   	 this.nom="Tyran";
   	 this.origine = "N��ant";
   	 this.dogme = "SymbolesChaos";
   	 this.nombreCroyant = 3;
    }
    
    //D��fausse tous les Croyants ayant le Dogme Mystique actuellement 
    //au centre de la table.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
