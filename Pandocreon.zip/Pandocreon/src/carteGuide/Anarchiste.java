package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Anarchiste extends GuideSpirituel {
	//contructeur
    public Anarchiste(){
   	 this.nom="anarchiste";
   	 this.dogme = "HumainChaos";
   	 this.origine = "N��ant";
   	 this.nombreCroyant = 3;
    }
    
    //Sacrifie un Guide Spirituel, si lui ou sa Divinit�� ne croit pas au Dogme Chaos. 
    //Les capacit��s sp��ciales sont jou��es normalement.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
