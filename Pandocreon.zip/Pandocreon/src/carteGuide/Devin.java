package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;

public class Devin extends GuideSpirituel {
	//contructeur
	
    public Devin(){
   	 this.nom="Devin";
   	 this.nombreCroyant = 1; 
   	 this.origine = "N��ant";
   	 this.dogme = "NatureMystique";
    }
    
    //Oblige une Divinit�� ayant le Dogme Nature ou Mystique �� sacrifier 
    //l'un de ses Guides Spirituels.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
