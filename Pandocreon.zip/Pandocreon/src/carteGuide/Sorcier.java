package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Sorcier extends GuideSpirituel{
	//contructeur
    public Sorcier(){
   	 this.nom="Sorcier";
   	 this.dogme = "MystiqueSymboles";
   	 this.origine = "Nuit";
   	 this.nombreCroyant = 3;
    }
    
    //Echangez l'un de vos Guides Spirituels avec un d'une autre Divinit��. 
    //Vous choisissez les deux guides Spirituels en question. 
    //Les Croyants restent attach��s aux m��mes cartes.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
