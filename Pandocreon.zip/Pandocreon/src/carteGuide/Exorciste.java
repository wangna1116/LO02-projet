package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Exorciste extends GuideSpirituel{
	//contructeur
    public Exorciste(){
   	 this.nom="Exorciste";
   	 this.origine = "Jour";
   	 this.dogme = "MystiqueChaos";
   	 this.nombreCroyant = 1;
    }
    
    //Une Divinit�� d'Origine Nuit ou ayant les Dogmes Mystique et Chaos 
    //reprend dans sa main l'un de ses Guides Spirituels. 
    //Les Croyants qui y ��taient attach��s sont d��fauss��s.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
