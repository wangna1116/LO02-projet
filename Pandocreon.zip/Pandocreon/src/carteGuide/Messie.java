package carteGuide;

import control.Joueur;
import carteAction.GuideSpirituel;


public class Messie extends GuideSpirituel{
	//contructeur
    public Messie(){
   	  this.nom="Messie";
   	  this.origine = "Jour";
   	  this.dogme = "HumainMystique";
   	  this.nombreCroyant =3;
    }
    
    //Le joueur pose le d�� de Cosmogonie sur la face qu'il d��sire et 
    //commence un nouveau tour de jeu.
    public void utiliserCapacite(Joueur j){
  	  
    }
}
