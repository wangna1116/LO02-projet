package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Nibillistes extends Croyant{
	//contructeur
    public Nibillistes(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "Nibillistes";
   	 this.origine = "N��ant";
   	 this.dogme = "SymbolesMystiqueChaos";
    }
    
    //Jusqu'�� la fin du tour, plus aucune Divinit�� ne recoit de points d'Action.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
