package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Alchimistes3 extends Croyant {
	public Alchimistes3(){
	     super();
	   	 this.nombrePuissance = 2;
	   	 this.nom = "Alchimistes3";
	   	 this.origine = "Nuit";
	   	 this.dogme = "MystiqueNatureChaos";
	    }
	    
	//Emp��che une Divinit�� poss��dant le Dogme Humain ou Symboles 
	//de sacrifier un de ses Guides Spirituels durant ce tour de jeu.
	public void utiliserCapacite(Joueur j){
    	
    	
    }

}
