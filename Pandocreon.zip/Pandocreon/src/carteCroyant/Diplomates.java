package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Diplomates extends Croyant{
	//contructeur
    public Diplomates(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "Diplomates";
   	 this.origine = "Jour";
   	 this.dogme = "SymbolesHumainChaos";
    }
    
    //Relancez le d�� de Cosmogonie. Le tour se finit normalement sous la nouvelle influence.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
