package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Ali��n��s2 extends Croyant {
	public Ali��n��s2(){
    	super();
      	 this.nombrePuissance = 2;
      	 this.nom = "Ali��n��s2";
      	 this.origine = "N��ant";
      	 this.dogme = "SymbolesHumainChaos";
    }
	
	//Emp��che une Divinit�� poss��dant le Dogme Nature ou Mystique 
	//de sacrifier une de ses cartes de Croyants durant ce tour.
	public void utiliserCapacite(Joueur j){
    	
    	
    }

}
