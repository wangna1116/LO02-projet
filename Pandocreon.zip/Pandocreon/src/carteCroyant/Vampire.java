package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class  Vampire extends Croyant {
	//contructeur
    public Vampire(){
     super();
   	 this.nombrePuissance = 1;
   	 this.nom = "Vampire";
   	 this.origine = "Nuit";
    }
    
    //Impose le sacrifice d'un Croyant d'un autre joueur. 
    //Celui-ci choisit le sacrifi��. La capacit�� sp��ciale du sacrifice est jou��e.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
