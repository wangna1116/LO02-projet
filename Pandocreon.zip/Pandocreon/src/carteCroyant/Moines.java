package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Moines extends Croyant {
	//contructeur
    public Moines(){
     super();
   	 this.nom="Moines";
   	 this.nombrePuissance = 2;
   	 this.origine = "Jour";
    }
    
    public void utiliserCapacite(Joueur j){
    	j.setPointActionJour(j.getPointActionJour() + 1);
    	
    }

}
