package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Lycanthropes extends Croyant{
	//contructeur
    public Lycanthropes(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "Lycanthropes";
   	 this.origine = "Nuit";
   	 this.dogme = "HumainNatureChaos";
    }
    
    //Retirez tous les Croyants attach��s �� l'un des Guides Spirituels d'une autre Divinit��. 
    //Les Croyants reviennent au milieu de la table, le Guide Spirituel est d��fauss��.
    public void utiliserCapacite(Joueur j){
    	
    }
    }
