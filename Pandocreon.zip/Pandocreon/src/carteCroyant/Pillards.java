package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Pillards extends Croyant {
	//contructeur
    public Pillards(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "Pillards";
   	 this.origine = "Nuit";
   	 this.dogme = "MystiqueNatureSymboles";
    }
    
    //R��cup��rez les points d'Action d'une Divinit�� n'ayant pas encore jou�� durant ce tour. 
    //Les points d'Action gardent leur Origine. La Divinit�� perd ses points.
    public void utiliserCapacite(Joueur j){
    	
    	
    }

}
