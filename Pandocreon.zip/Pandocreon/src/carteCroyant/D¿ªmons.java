package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class D��mons extends Croyant {
	//contructeur
    public D��mons(){
     super();
   	 this.nombrePuissance = 2;
   	 this.nom = "D��mons";
   	 this.origine = "Nuit";
    }
    
    public void utiliserCapacite(Joueur j){
    	j.setPointActionNuit(j.getPointActionNuit() + 1);
    	
    }

}
