package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Ali��n��s1 extends Croyant {
	public Ali��n��s1(){
    	super();
      	 this.nombrePuissance = 2;
      	 this.nom = "Ali��n��s1";
      	 this.origine = "N��ant";
      	 this.dogme = "MystiqueHumainChaos";
    }
	
	//Vous piochez deux cartes au hasard dans la main d'une autre Divinit��.
	public void utiliserCapacite(Joueur j){
    	
    	
    }
	

}
