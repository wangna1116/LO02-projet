package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Revenant extends Croyant{
	//contructeur
    public Revenant(){
     super();
   	 this.nombrePuissance = 1;
   	 this.nom = "Revenant";
   	 this.origine = "N��ant";
   	 this.dogme = "HumainNatureMystique";
    }
    
    //Relancez le d�� de Cosmogonie. Le tour se finit normalement sous la nouvelle influence.
    public void utiliserCapacite(Joueur j){
    	
    	
    }

}
