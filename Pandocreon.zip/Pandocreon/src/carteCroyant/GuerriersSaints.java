package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class GuerriersSaints extends Croyant{
	//contructeur
    public GuerriersSaints(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "GuerriersSaints";
   	 this.origine = "Jour";
   	 this.dogme = "MystiqueNatureSymboles";
    }
    
    //Un Guide Spirituel revient dans la main de sa Divinit��. 
    //Ses Croyants reviennent au centre de la table.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
