package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Ali��n��s3 extends Croyant {
	
	public Ali��n��s3(){
    	super();
      	 this.nombrePuissance = 2;
      	 this.nom = "Ali��n��s3";
      	 this.origine = "N��ant";
      	 this.dogme = "SymbolesHumainNature";
    }
	
	//Emp��che une Divinit�� poss��dant le Dogme Chaos ou Mystique 
	//de sacrifier un de ses Guides Spirituels durant ce tour.
	public void utiliserCapacite(Joueur j){
    	
    	
    }
	
	

}
