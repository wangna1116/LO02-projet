package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Ermite extends Croyant{
	//contructeur
    public Ermite(){
     super();
   	 this.nombrePuissance = 1;
   	 this.nom = "Ermite";
   	 this.origine = "Jour";
    }
    
    //Impose le sacrifice d'un Croyant d'un autre joueur, qui choisit la carte. 
    //La capacit�� sp��ciale du sacrifice est jou��e.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
