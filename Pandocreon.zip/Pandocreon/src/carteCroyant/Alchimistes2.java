package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Alchimistes2 extends Croyant {
	public Alchimistes2(){
		super();
		this.nombrePuissance = 2;
		this.nom = "Alchimistes2";
		this.origine = "Nuit";
		this.dogme = "SymbolesNatureChaos";
	}
	
	  //Emp��che une Divinit�� poss��dant le Dogme Humain ou Mystique 
	  //de sacrifier une de ses cartes de Croyants durant ce tour de jeu.
	public void utiliserCapacite(Joueur j){
		
	}

}
