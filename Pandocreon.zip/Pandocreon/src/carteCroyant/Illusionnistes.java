package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Illusionnistes extends Croyant{
	//contructeur
    public Illusionnistes(){
     super();
   	 this.nombrePuissance = 4;
   	 this.nom = "Illusionnistes";
   	 this.origine = "Nuit";
   	 this.dogme = "SymbolesHumainChaos";
    }
    
    //Vous b��n��ficiez de la capacit�� sp��ciale de sacrifice d'une carte de Croyants 
    //appartenant �� une autre Divinit��. La carte en question reste en jeu.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
