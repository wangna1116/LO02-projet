package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Travailleurs3 extends Croyant {
	//contructeur
    public Travailleurs3(){
     super();
   	 this.nombrePuissance = 2;
   	 this.nom = "Travailleurs3";
   	 this.origine = "Jour";
   	 this.dogme = "SymbolesHumainNature";
    }
    
    //Emp��che une Divinit�� poss��dant le Dogme Chaos ou Mystique 
    //de sacrifier un de ses Guides Spirituels durant ce tour.
    public void utiliserCapacite(Joueur j){
    	
    	
    }


}
