package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Int��gristes extends Croyant{
	//contructeur
    public Int��gristes(){
     super();
   	 this.nombrePuissance = 1;
   	 this.nom = "Int��gristes";
   	 this.origine = "Jour";
   	 this.dogme = "MystiqueNatureChaos";
    }
    
    //Impose le sacrifice d'un Guide Spirituel d'un autre joueur, qui choisit la carte. 
    //La capacit�� sp��ciale du sacrifice est jou��e.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
