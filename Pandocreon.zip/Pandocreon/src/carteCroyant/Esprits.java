package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class Esprits extends Croyant {
	//contructeur
    public Esprits(){
    	super();
      	 this.nombrePuissance = 2;
      	 this.nom = "Esprits";
      	 this.origine = "N��ant";
    }
    
    //Donne un point d'Action d'Origine N��ant.
    public void utiliserCapacite(Joueur j){
    	j.setPointActionN��ant(j.getPointActionN��ant() + 1);
    	
    }
}
