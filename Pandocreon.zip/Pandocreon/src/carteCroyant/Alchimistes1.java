package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Alchimistes1 extends Croyant {
	public Alchimistes1(){
		super();
		this.nombrePuissance = 2;
		this.nom = "Alchimistes1";
		this.origine = "Nuit";
		this.dogme = "SymbolesNatureChaos";
	}
	
	  //Vous piochez deux cartes au hasard dans la main d'une autre Divinit��.
	public void utiliserCapacite(Joueur j){
		
	}

}
