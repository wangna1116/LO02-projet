package carteCroyant;

import carteAction.Croyant;
import control.Joueur;


public class R��volutionnaires extends Croyant{
	//contructeur
    public R��volutionnaires(){
     super();
   	 this.nombrePuissance = 2;
   	 this.nom = "R��volutionnaires";
   	 this.origine = "N��ant";
   	 this.dogme = "SymbolesHumainChaos";
    }
    
    //Imposez le sacrifice d'une carte de Croyants �� autant de Divinit��s que vous le voulez. 
    //Chaque Divinit�� choisit la carte �� sacrifier. Les capacit��s sp��ciales sont jou��es.
    public void utiliserCapacite(Joueur j){
    	
    	
    }
}
