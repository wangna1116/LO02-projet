package carteCroyant;

import carteAction.Croyant;
import control.Joueur;

public class Travailleurs1 extends Croyant {
	//contructeur
    public Travailleurs1(){
     super();
   	 this.nombrePuissance = 2;
   	 this.nom = "Travailleurs1";
   	 this.origine = "Jour";
   	 this.dogme = "MystiqueHumainChaos";
    }
    
    //Vous piochez deux cartes au hasard dans la main d'une autre Divinit��.
    public void utiliserCapacite(Joueur j){
    	
    	
    }

}
