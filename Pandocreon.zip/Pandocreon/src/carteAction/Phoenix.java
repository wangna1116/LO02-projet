package carteAction;

public class Phoenix extends DeusEx{
	//contructeur
    public Phoenix(String Phoenix){
   	 this.nom=Phoenix;
    }
}
