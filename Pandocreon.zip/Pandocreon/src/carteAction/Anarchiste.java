package carteAction;

public class Anarchiste extends GuideSpirituel {
	//contructeur
    public Anarchiste(String anarchiste){
   	 this.nom=anarchiste;
    }
}
