package carteAction;

public class Diplomates extends Croyant{
	//contructeur
    public Diplomates(String Diplomates){
   	 this.nom=Diplomates;
    }
}
