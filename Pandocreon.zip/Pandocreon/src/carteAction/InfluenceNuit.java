package carteAction;

public class InfluenceNuit extends DeusEx{
	//contructeur
    public InfluenceNuit(String InfluenceNuit){
   	 this.nom=InfluenceNuit;
    }
}
