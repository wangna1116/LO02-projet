package carteAction;

public class Sorcier extends GuideSpirituel{
	//contructeur
    public Sorcier(String Sorcier){
   	 this.nom=Sorcier;
    }
}
