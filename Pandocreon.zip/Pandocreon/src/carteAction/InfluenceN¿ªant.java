package carteAction;

public class InfluenceN��ant extends DeusEx{
	//contructeur
    public InfluenceN��ant(String InfluenceN��ant){
   	 this.nom=InfluenceN��ant;
    }
}
