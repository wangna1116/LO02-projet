package carteAction;

public class Transe extends DeusEx{
	//contructeur
    public Transe(String Transe){
   	 this.nom=Transe;
    }
}
