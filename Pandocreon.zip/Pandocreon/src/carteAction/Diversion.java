package carteAction;

public class Diversion extends DeusEx{
	//constructeur
		public Diversion(String Diversion){
			this.nom=Diversion;
		}
}
