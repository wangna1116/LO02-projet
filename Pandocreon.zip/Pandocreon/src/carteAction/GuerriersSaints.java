package carteAction;

public class GuerriersSaints extends Croyant{
	//contructeur
    public GuerriersSaints(String GuerriersSaints){
   	 this.nom=GuerriersSaints;
    }
}
