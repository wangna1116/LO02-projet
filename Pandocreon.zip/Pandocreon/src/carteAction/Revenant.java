package carteAction;

public class Revenant extends Croyant{
	//contructeur
    public Revenant (String Revenant){
   	 this.nom=Revenant;
    }
}
