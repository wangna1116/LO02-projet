package carteAction;

import control.Joueur;

public class Croyant extends CarteAction{
	protected int nombrePuissance;
	protected int numeroCarteRattacher;
	
	  //le constructeur
	public Croyant(){
		super();
		this.type = "Croyant";
	}
	
	  //capacite 
	public void utiliserCapacite(Joueur j){
		
	}
	
	public void poserCroyant(Joueur j){
		
	}

	
	  //Getters & Setters
	public int getNombrePuissance() {
		return nombrePuissance;
	}

	public void setNombrePuissance(int nombrePuissance) {
		this.nombrePuissance = nombrePuissance;
	}

	public int getNumeroCarteRattacher() {
		return numeroCarteRattacher;
	}

	public void setNumeroCarteRattacher(int numeroCarteRattacher) {
		this.numeroCarteRattacher = numeroCarteRattacher;
	}
	
	
}
