package carteAction;

public class Clerc extends GuideSpirituel {
	//contructeur
    public Clerc(String clerc){
   	 this.nom=clerc;
    }
}
