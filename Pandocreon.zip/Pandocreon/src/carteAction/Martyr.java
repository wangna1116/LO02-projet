package carteAction;

public class Martyr extends GuideSpirituel{
	//contructeur
    public Martyr(String Martyr){
   	 this.nom=Martyr;
    }
}
