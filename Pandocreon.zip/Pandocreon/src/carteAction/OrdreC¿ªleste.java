package carteAction;

public class OrdreC��leste extends DeusEx{
	//contructeur
    public OrdreC��leste(String OrdreC��leste){
   	 this.nom=OrdreC��leste;
    }
}
