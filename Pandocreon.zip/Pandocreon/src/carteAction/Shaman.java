package carteAction;

public class Shaman extends GuideSpirituel{
	//contructeur
    public Shaman(String Shaman){
   	 this.nom=Shaman;
    }
}
