package carteAction;

public class Bouleversement extends DeusEx{
    //constructeur
	public  Bouleversement(String bouleversement){
		this.nom=bouleversement;
	}
}
