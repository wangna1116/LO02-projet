package carteAction;

public class Nibillistes extends Croyant{
	//contructeur
    public Nibillistes (String Nibillistes){
   	 this.nom=Nibillistes;
    }
}
