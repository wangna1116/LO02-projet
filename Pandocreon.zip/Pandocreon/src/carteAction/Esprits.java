package carteAction;

public class Esprits extends Croyant {
	//contructeur
    public Esprits(String Esprits){
   	 this.nom=Esprits;
    }
}
