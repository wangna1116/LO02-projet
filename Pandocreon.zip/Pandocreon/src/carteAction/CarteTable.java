package carteAction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CarteTable {
	
	private static CarteTable carteTable;
	private ArrayList<CarteAction> croyantEnTable;
	
	  //le constructeur
	public CarteTable() {
		setCroyantEnTable(new ArrayList<CarteAction>());

	}
	
	public void ajouterCroyant(Croyant objet){
		croyantEnTable.add(objet);
	}
	
	public void supprimerCroyant(Croyant croyant){
		Iterator it= croyantEnTable.iterator();
		while (it.hasNext()){
			Croyant cy=(Croyant)it.next(); 
			if (cy==croyant){
				it.remove();
			}
		}
	}
	
	  //imprimer carte table
	public void printCarteTable(){
		Iterator it= croyantEnTable.iterator();
		System.out.println("imprimer les carte en table:");
		while (it.hasNext())
		{
			Croyant cr=(Croyant)it.next();
			System.out.println("Nom de la carte croyant: " + cr.getNom());
		}
	}
	
	
	  //Getters & Setters
	public static CarteTable getCarteTable() {
		carteTable = new CarteTable();
		return carteTable;
	}
	
	public ArrayList<CarteAction> getCroyantEnTable() {
		return croyantEnTable;
	}
	public void setCroyantEnTable(ArrayList<CarteAction> croyantEnTable) {
		this.croyantEnTable = croyantEnTable;
	}


}
