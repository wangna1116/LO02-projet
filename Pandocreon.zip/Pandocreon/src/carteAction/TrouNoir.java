package carteAction;

public class TrouNoir extends DeusEx{
	//contructeur
    public TrouNoir(String TrouNoir){
   	 this.nom=TrouNoir;
    }
}
