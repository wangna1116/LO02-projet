package carteAction;

public class Divin extends GuideSpirituel{
	//contructeur
    public Divin(String Divin){
   	 this.nom=Divin;
    }
}
