package carteAction;

public class Inquisition extends DeusEx{
	//contructeur
    public Inquisition(String Inquisition){
   	 this.nom=Inquisition;
    }
}
