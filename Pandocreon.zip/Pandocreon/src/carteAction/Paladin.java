package carteAction;

public class Paladin extends GuideSpirituel{
	//contructeur
    public Paladin(String Paladin){
   	 this.nom=Paladin;
    }
}
