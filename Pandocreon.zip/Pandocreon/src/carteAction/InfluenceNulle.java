package carteAction;

public class InfluenceNulle extends DeusEx{
	//contructeur
    public InfluenceNulle(String InfluenceNulle){
   	 this.nom=InfluenceNulle;
    }
}
