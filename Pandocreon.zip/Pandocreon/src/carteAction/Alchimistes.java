package carteAction;

public class Alchimistes extends Croyant{
	 //contructeur
     public Alchimistes(String alchimistes){
    	 this.nom=alchimistes;
     }
}
