package carteAction;

public class Pilladrs extends Croyant{
	//contructeur
    public Pilladrs  (String Pilladrs){
   	 this.nom=Pilladrs;
    }
} 
