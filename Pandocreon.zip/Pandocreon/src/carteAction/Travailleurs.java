package carteAction;

public class Travailleurs extends Croyant{
	//contructeur
    public Travailleurs  (String Travailleurs){
   	 this.nom=Travailleurs;
    }
}
