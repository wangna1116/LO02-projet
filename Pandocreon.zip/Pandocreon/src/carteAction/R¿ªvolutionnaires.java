package carteAction;

public class R��volutionnaires extends Croyant{
	//contructeur
    public R��volutionnaires (String R��volutionnaires){
   	 this.nom=R��volutionnaires;
    }
}
