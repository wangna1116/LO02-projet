package carteAction;

public class Col��reDivine extends DeusEx {
	//constructeur
		public  Col��reDivine(String Col��reDivine){
			this.nom=Col��reDivine;
		}
}
