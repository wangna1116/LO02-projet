package carteAction;

public class Ermite extends Croyant{
	//contructeur
    public Ermite(String Ermite){
   	 this.nom=Ermite;
    }
}
