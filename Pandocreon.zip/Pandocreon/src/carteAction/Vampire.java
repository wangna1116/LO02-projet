package carteAction;

public class  Vampire extends Croyant {
	//contructeur
    public Vampire (String Vampire){
   	 this.nom=Vampire;
    }
}
