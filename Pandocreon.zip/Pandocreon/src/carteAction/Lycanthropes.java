package carteAction;

public class Lycanthropes extends Croyant{
	//contructeur
    public Lycanthropes (String Lycanthropes){
   	 this.nom=Lycanthropes;
    }
}
