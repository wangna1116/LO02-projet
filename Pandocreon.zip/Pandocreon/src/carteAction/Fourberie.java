package carteAction;

public class Fourberie extends DeusEx{
	//contructeur
    public Fourberie(String Fourberie){
   	 this.nom=Fourberie;
    }
}
