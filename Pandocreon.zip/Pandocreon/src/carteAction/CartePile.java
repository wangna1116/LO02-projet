package carteAction;
import java.util.List;

import divinite.Divinite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import control.Partie;
import carteCroyant.Alchimistes1;
import carteCroyant.Alchimistes2;
import carteCroyant.Alchimistes3;
import carteCroyant.Ali��n��s1;
import carteCroyant.Ali��n��s2;
import carteCroyant.Ali��n��s3;
import carteCroyant.Diplomates;
import carteCroyant.D��mons;
import carteCroyant.Ermite;
import carteCroyant.Esprits;
import carteCroyant.GuerriersSaints;
import carteCroyant.Illusionnistes;
import carteCroyant.Int��gristes;
import carteCroyant.Lycanthropes;
import carteCroyant.Moines;
import carteCroyant.Nibillistes;
import carteCroyant.Pillards;
import carteCroyant.Revenant;
import carteCroyant.R��volutionnaires;
import carteCroyant.Travailleurs1;
import carteCroyant.Travailleurs2;
import carteCroyant.Travailleurs3;
import carteCroyant.Vampire;
import carteDeusEx.Bouleversement;
import carteDeusEx.Col��reDivineJour;
import carteDeusEx.Col��reDivineNuit;
import carteDeusEx.Concentration;
import carteDeusEx.Diversion;
import carteDeusEx.Fourberie;
import carteDeusEx.InfluenceJour;
import carteDeusEx.InfluenceNuit;
import carteDeusEx.InfluenceNulle;
import carteDeusEx.InfluenceN��ant;
import carteDeusEx.Inquisition;
import carteDeusEx.Miroir;
import carteDeusEx.OrdreC��leste;
import carteDeusEx.Phoenix;
import carteDeusEx.Stase;
import carteDeusEx.Transe;
import carteDeusEx.TrouNoir;
import carteGuide.Anarchiste;
import carteGuide.Asc��te;
import carteGuide.Clerc;
import carteGuide.Devin;
import carteGuide.Exorciste;
import carteGuide.Martyr;
import carteGuide.Messie;
import carteGuide.Paladin;
import carteGuide.Shaman;
import carteGuide.Sorcier;
import carteGuide.Tyran;

public class CartePile {
	public List cartes;
	private static CartePile cartePile = new CartePile();
	
	  //constructeur
	public CartePile(){
		this.cartes=new ArrayList();
		creerLesCartesCroyants();
		creerLesCartesGuideSpirituel();
		creerLesCartesDeusEx();
		creerLesCartesApocalypse();
	}
	
	  //creer tout les cartes croyants
	public void creerLesCartesCroyants(){
		  //creer les cartes croyants qui s'appelle "Moine"
		Moines moines1=new Moines();
		cartes.add(moines1);
		moines1.setDogme("MystiqueHumainChaos");
		Moines moines2=new Moines();
		cartes.add(moines2);
		moines2.setDogme("SymbolesMystiqueChaos");
		Moines moines3=new Moines();
		cartes.add(moines3);
		moines3.setDogme("MystiqueNatureSymboles");
		Moines moines4=new Moines();
		cartes.add(moines4);
		moines4.setDogme("MystiqueNatureChaos");
		Moines moines5=new Moines();
		cartes.add(moines5);
		moines5.setDogme("HumainNatureMystique");
		
		  //creer les cartes croyants qui s'appelle "D��mon"  
		D��mons d��mons1=new D��mons();
		cartes.add(d��mons1);
		d��mons1.setDogme("MystiqueHumainChaos");
		D��mons d��mons2=new D��mons();
		cartes.add(d��mons2);
		d��mons2.setDogme("SymbolesMystiqueChaos");
	   D��mons d��mons3=new D��mons();
	   cartes.add(d��mons3);
	   d��mons3.setDogme("MystiqueNatureSymboles");
	   D��mons d��mons4=new D��mons();
	   cartes.add(d��mons4);
	   d��mons4.setDogme("HumainNatureMystique");
	   D��mons d��mons5=new D��mons();
	   cartes.add(d��mons5);
	   d��mons5.setDogme("MystiqueNatureChaos");
	   
	   //creer les cartes croyants qui s'appelle "Esprits"
	   Esprits esprits1=new Esprits();
	   cartes.add(esprits1);
	   esprits1.setDogme("SymbolesMystiqueChaos");
	   Esprits esprits2=new Esprits();
	   cartes.add(esprits2);
	   esprits2.setDogme("MystiqueNatureChaos");
	   Esprits esprits3=new Esprits();
	   cartes.add(esprits3);
	   esprits3.setDogme("MystiqueNatureSymboles");
	   Esprits esprits4=new Esprits();
	   cartes.add(esprits4);
	   esprits4.setDogme("MystiquesHumainChaos");
	   Esprits esprits5=new Esprits();
	   cartes.add(esprits5);
	   esprits5.setDogme("HumainNatureMystique");
	   
	   //creer les cartes croyants qui s'appelle "Travailleurs"
	   Travailleurs1 travailleurs1=new Travailleurs1();
	   cartes.add(travailleurs1);
	   Travailleurs2 travailleurs2=new Travailleurs2();
	   cartes.add(travailleurs2);
	   Travailleurs3 travailleurs3=new Travailleurs3();
	   cartes.add(travailleurs3);
	   
	   //creer les cartes croyants qui s'appelle "Ali��n��"
	   Ali��n��s1 ali��n��s1=new Ali��n��s1();
	   cartes.add(ali��n��s1);
	   Ali��n��s2 ali��n��s2=new Ali��n��s2();
	   cartes.add(ali��n��s2);
	   Ali��n��s3 ali��n��s3=new Ali��n��s3();
	   cartes.add(ali��n��s3);
		 
	   //creer les cartes croyants qui s'appelle "Alchimistes"
	   Alchimistes1 alchimistes1=new Alchimistes1();
	   cartes.add(alchimistes1);
	   Alchimistes2 alchimistes2=new Alchimistes2();
	   cartes.add(alchimistes2);
	   Alchimistes3 alchimistes3=new Alchimistes3();
	   cartes.add(alchimistes3);
		
	   //creer les cartes croyants qui s'appelle 'Ermite"
	   Ermite ermite1=new Ermite();
	   cartes.add(ermite1);
	   ermite1.setDogme("MystiqueNatureSymboles");
	   Ermite ermite2=new Ermite();
	   cartes.add(ermite2);
	   ermite2.setDogme("MystiqueNatureChaos");
	   
	   //creer les cartes croyants qui s'appelle "Vampire"
	   Vampire vampire1=new Vampire();
		cartes.add(vampire1);
		vampire1.setDogme("HumainNatureSymboles");
		Vampire vampire2=new Vampire();
		cartes.add(vampire2);
		vampire2.setDogme("MystiqueHumainChaos");
		
	   //creer les cartes croyants qui s'appelle "R��volutionnaires"
	   R��volutionnaires r��volutionnaires=new R��volutionnaires();
	   cartes.add(r��volutionnaires);
	  
	   //creer les cartes croyants qui s'appelle "Int��gristes"
	   
	   Int��gristes int��gristes=new Int��gristes();
	   cartes.add(int��gristes);
	   
	   //creer les cartes croyants qui s'appelle "Guerriers Saints"
		
	   GuerriersSaints guerriersSaints=new GuerriersSaints();
	   cartes.add(guerriersSaints);
			  
	  //creer les cartes croyants qui s'appelle "Lycanthropes"
		
	   Lycanthropes lycanthropes=new Lycanthropes();
	   cartes.add(lycanthropes);
	  //creer les cartes croyants qui s'appelle "Diplomates"
	  
	   Diplomates diplomates=new Diplomates();
	   cartes.add(diplomates);
			   
	  //creer les cartes croyants qui s'appelle "Revenant"
			   
	   Revenant revenant=new Revenant();
	   cartes.add(revenant);   
	  //creer les cartes croyants qui s'appelle "Pilladrs"
	   
	   Pillards pillards=new Pillards();
	   cartes.add(pillards);
			   
	  //creer les cartes croyants qui s'appelle "Illusionnistes"
			   
	   Illusionnistes illusionnistes=new Illusionnistes();
	   cartes.add(illusionnistes);
			   
	  //creer les cartes croyants qui s'appelle 'Nibillistes"
			   
	   Nibillistes nibillistes=new Nibillistes();
	   cartes.add(nibillistes);
			   
   } 

	
	  //creer tout les cartes GuideSpirituel
	public void creerLesCartesGuideSpirituel(){
		
		  //creer les cartes GuideSpirituel qui s'appelle "Martyr"
		Martyr martyr1=new Martyr();
		cartes.add(martyr1);
		martyr1.setOrigine("Jour");
		martyr1.setDogme("NatureHumain");
		Martyr martyr2=new Martyr();
		cartes.add(martyr2);
		martyr2.setOrigine("Nuit");
		martyr2.setDogme("HumainSymboles");
		Martyr martyr3=new Martyr();
		cartes.add(martyr3);
		martyr3.setOrigine("N��ant");
		martyr3.setDogme("NatureChaos");
		
		  //creer les cartes GuideSpirituel qui s'appelle "Clerc"
		Clerc clerc1=new Clerc();
		cartes.add(clerc1);
		clerc1.setOrigine("Jour");
		clerc1.setDogme("NatureChaos");
		Clerc clerc2=new Clerc();
		cartes.add(clerc2);
		clerc2.setOrigine("Jour");
		clerc2.setDogme("MystiqueChaos");
		Clerc clerc3=new Clerc();
		cartes.add(clerc3);
		clerc3.setOrigine("Jour");
		clerc3.setDogme("HumainChaos");
		Clerc clerc4=new Clerc();
		cartes.add(clerc4);
		clerc4.setOrigine("Nuit");
		clerc4.setDogme("HumainNature");
		Clerc clerc5=new Clerc();
		cartes.add(clerc5);
		clerc5.setOrigine("Nuit");
		clerc5.setDogme("NatureSymboles");
		Clerc clerc6=new Clerc();
		cartes.add(clerc6);
		clerc6.setOrigine("Nuit");
		clerc6.setDogme("MystiqueSymboles");
		Clerc clerc7=new Clerc();
		cartes.add(clerc7);
		clerc7.setOrigine("N��ant");
		clerc7.setDogme("SymbolesChaos");
		Clerc clerc8=new Clerc();
		cartes.add(clerc8);
		clerc8.setOrigine("N��ant");
		clerc8.setDogme("NatureMystique");
		
		  //creer les cartes GuideSpirituel qui s'appelle "Shaman"
		Shaman shaman=new Shaman();
		cartes.add(shaman);
		
		  //creer les cartes GuideSpirituel qui s'appelle "Anarchiste"
		Anarchiste anarchiste=new Anarchiste();
		cartes.add(anarchiste);
	   
	  //creer les cartes GuideSpirituel qui s'appelle "Paladin"
	   
	   Paladin paladin=new Paladin();
	   cartes.add(paladin);
	   
	   //creer les cartes GuideSpirituel qui s'appelle "Asc��te"
	   
	   Asc��te asc��te=new Asc��te();
	   cartes.add(asc��te);
	   
       //creer les cartes GuideSpirituel qui s'appelle "divin"
	   
	   Devin devin=new Devin();
	   cartes.add(devin);
	   
       //creer les cartes GuideSpirituel qui s'appelle "Exorciste"
	   
	   Exorciste exorciste=new Exorciste();
	   cartes.add(exorciste);
	   
       //creer les cartes GuideSpirituel qui s'appelle "Sorcier"
	   
	   Sorcier sorcier=new Sorcier();
	   cartes.add(sorcier);
	   
       //creer les cartes GuideSpirituel qui s'appelle "Tyran"
	   
       Tyran tyran=new Tyran();
	   cartes.add(tyran);
	   
       //creer les cartes GuideSpirituel qui s'appelle "Messie"
	   
	   Messie messie=new Messie();
	   cartes.add(messie);

   }
	
	  //creer tout les cartes DeusEx
	public void  creerLesCartesDeusEx(){
		  //creer les cartes DeusEx qui s'appelle "Col��re Divine"
		Col��reDivineJour col��reDivineJour=new Col��reDivineJour();
		cartes.add(col��reDivineJour);
		Col��reDivineNuit col��reDivineNuit=new Col��reDivineNuit();
		cartes.add(col��reDivineNuit);
	   
	   //creer les cartes DeusEx qui s'appelle "Stase"
	   Stase stase=new Stase();
       cartes.add(stase);
	   
	   //creer les cartes DeusEx qui s'appelle "Ordre C��leste"
	   OrdreC��leste ordreC��leste=new OrdreC��leste();
	   cartes.add(ordreC��leste);
	   
	   //creer les cartes DeusEx qui s'appelle "Concentration"
	   Concentration concentration=new Concentration();
	   cartes.add(concentration);
	   
	   //creer les cartes DeusEx qui s'appelle "Fourberie"
	   Fourberie fourberie=new Fourberie();
	   cartes.add(fourberie);
	   
	   //creer les cartes DeusEx qui s'appelle "Diversion"
	   Diversion diversion=new Diversion();
	   cartes.add(diversion);
	   
       //creer les cartes DeusEx qui s'appelle "Trou Noir"
	   TrouNoir trouNoir=new TrouNoir();
	   cartes.add(trouNoir);
	   
       //creer les cartes DeusEx qui s'appelle "Phoenix"
	   Phoenix phoenix=new Phoenix();
	   cartes.add(phoenix);
	   
       //creer les cartes DeusEx qui s'appelle "Influence Jour"
	   InfluenceJour influenceJour=new InfluenceJour();
	   cartes.add(influenceJour);
	   
       //creer les cartes DeusEx qui s'appelle "Influence Nuit"
	   InfluenceNuit influenceNuit=new InfluenceNuit();
	   cartes.add(influenceNuit);
	   
       //creer les cartes DeusEx qui s'appelle "Influence N��ant"
	   InfluenceN��ant influenceN��ant=new InfluenceN��ant();
	   cartes.add(influenceN��ant);
	   
	   //creer les cartes DeusEx qui s'appelle "Influence Nulle"
	   for(int i=0;i<2;i++){
		   InfluenceNulle influenceNulle=new InfluenceNulle();
		   cartes.add(influenceNulle);
	   }
	   
       //creer les cartes DeusEx qui s'appelle "Transe"
	   Transe transe=new Transe();
	   cartes.add(transe);
	   
       //creer les cartes DeusEx qui s'appelle "Miroir"
	   Miroir miroir=new Miroir();
	   cartes.add(miroir);
	   
       //creer les cartes DeusEx qui s'appelle "Bouleversement"
	   Bouleversement bouleversement=new Bouleversement();
	   cartes.add(bouleversement);
	   
       //creer les cartes DeusEx qui s'appelle "Inquisition"
	   Inquisition inquisition=new Inquisition();
	   cartes.add(inquisition);
   }
	public void creerLesCartesApocalypse(){
		  //creer les cartes Apocalypse 
		Apocalypse apocalypse1=new Apocalypse();
		cartes.add(apocalypse1);
		apocalypse1.setOrigine("Jour");
		Apocalypse apocalypse2=new Apocalypse();
		cartes.add(apocalypse2);
		apocalypse2.setOrigine("Nuit");
		Apocalypse apocalypse3=new Apocalypse();
		cartes.add(apocalypse3);
		apocalypse3.setOrigine("N��ant");
		Apocalypse apocalypse4=new Apocalypse();
		cartes.add(apocalypse4);
		apocalypse4.setOrigine("");
		Apocalypse apocalypse5=new Apocalypse();
		cartes.add(apocalypse5);
		apocalypse5.setOrigine("");
	}
	  
	
	  //test si tout les cartes sont ajoutes
	public void test(){
		int size =cartes.size();
		for(int i=0;i<size;i++){
			CarteAction test=(CarteAction)cartes.get(i);
			System.out.println(test.nom);
		}
	}
	
	  //Touiller les cartes
	public void touiller() {
		Collections.shuffle(cartes);
	}
	
	public static CartePile renouveaulerCartePile() {
		if(cartePile == null) {
			cartePile = new CartePile();
		}
		return cartePile;
	}
	
	 //imprimer carte pile
	public void printCartePile(){
		Iterator it= cartes.iterator();
		System.out.println("imprimer la carte pile:");
		while (it.hasNext())
		{
			CarteAction ca=(CarteAction)it.next();
			System.out.println("Nom de la carte : " + ca.getNom());
		}
	}
	
	
	  //tirer carte du dessus
	public CarteAction tirerCarteDuDessus(){
		int i=cartes.size();
		int j=i-1;
		CarteAction carte=(CarteAction)cartes.get(j);
		cartes.remove(j);
		return carte;
	}
	
	
	public static CartePile getCartePile() {
		return cartePile;
	}
	
	public static void setCartePile(CartePile cartePile) {
		CartePile.cartePile = cartePile;
	}
	
	public List getCartes() {
		return cartes;
	}
	
	public void setCartes(List cartes) {
		this.cartes = cartes;
	}
	
	
}
