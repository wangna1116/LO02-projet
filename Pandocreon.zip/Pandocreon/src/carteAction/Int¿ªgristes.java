package carteAction;

public class Int��gristes extends Croyant{
	//contructeur
    public Int��gristes(String Int��gristes){
   	 this.nom=Int��gristes;
    }
}
