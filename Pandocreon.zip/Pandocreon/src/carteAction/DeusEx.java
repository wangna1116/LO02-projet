package carteAction;

import control.Joueur;


public class DeusEx extends CarteAction {
	  //le constructeur
	public DeusEx(){
		super();
		this.type = "DeusEx";
	}
	/**
    * ��дCarteAction��ʹ�ÿ�����
    */
	
	  //capacite 
	public void utiliserCapacite(Joueur j){
		
	}
     
     
     
}
