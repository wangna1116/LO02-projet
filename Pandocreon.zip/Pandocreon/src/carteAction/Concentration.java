package carteAction;

public class Concentration extends DeusEx {
	//constructeur
		public  Concentration(String Concentration){
			this.nom=Concentration;
		}
	
}
