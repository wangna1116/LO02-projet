package carteAction;

public class Exorciste extends GuideSpirituel{
	//contructeur
    public Exorciste(String Exorciste){
   	 this.nom=Exorciste;
    }
}
