package carteAction;

import control.Joueur;


public class GuideSpirituel extends CarteAction{
	  // les croyants qui a deja ramene
	protected int[] nombreCroyantRamener;
	  //le nombre des croyant il peut ramener
	protected int nombreCroyant;
	
	  //le constructeur
	public GuideSpirituel(){
		super();
		this.type = "GuideSpirituel";
	}
	/**
	 * ��дcarteAction��ʹ�ü��ܷ���
	 */
	  //capacite 
	public void utiliserCapacite(Joueur j){
		
	}
	
	public int[] getNombreCroyantRamener() {
		return nombreCroyantRamener;
	}
	
	public void setNombreCroyantRamener(int[] nombreCroyantRamener) {
		this.nombreCroyantRamener = nombreCroyantRamener;
	}
	
	public int getNombreCroyant() {
		return nombreCroyant;
	}
	
	public void setNombreCroyant(int nombreCroyant) {
		this.nombreCroyant = nombreCroyant;
	}

  
}
