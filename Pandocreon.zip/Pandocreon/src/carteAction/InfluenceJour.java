package carteAction;

public class InfluenceJour extends DeusEx{
	//contructeur
    public InfluenceJour(String InfluenceJour){
   	 this.nom=InfluenceJour;
    }
}
