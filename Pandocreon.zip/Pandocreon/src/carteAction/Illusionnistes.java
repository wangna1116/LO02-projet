package carteAction;

public class Illusionnistes extends Croyant{
	//contructeur
    public Illusionnistes(String Illusionnistes){
   	 this.nom=Illusionnistes;
    }
}
