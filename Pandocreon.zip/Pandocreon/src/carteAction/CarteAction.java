package carteAction;

import control.Joueur;
import control.Partie;

public class CarteAction {
	  //les attributes des carteAction en common
	private int numeroCarte;
	protected String origine;
	protected String dogme;
	protected String nom;
	protected String type;
	protected int numCarteAction;
	/**
	 * 
	 */
	protected Partie partie;
	
	  //le constructeur
	public CarteAction(){
		  //��ʼ������
		this.partie = Partie.getPartie();
	}
	
	
	/**
	 * �����ж���ʹ�ü��ܵĸ��෽��
     * ��֪���������joueur�ӵĶԲ���
	 */
	//
	public void utiliserCapacite(Joueur joueur){
	  
    }
	
	
	  //Getters & Setters
	public int getNumeroCarte() {
		return numeroCarte;
	}


	public void setNumeroCarte(int numeroCarte) {
		this.numeroCarte = numeroCarte;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getOrigine() {
		return origine;
	}


	public void setOrigine(String origine) {
		this.origine = origine;
	}


	public String getDogme() {
		return dogme;
	}


	public void setDogme(String dogme) {
		this.dogme = dogme;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public int getNumCarteAction() {
		return numCarteAction;
	}


	public void setNumCarteAction(int numCarteAction) {
		this.numCarteAction = numCarteAction;
	}
	
	
	
}
