package carteAction;

public class Miroir extends DeusEx{
	//contructeur
    public Miroir(String Miroir){
   	 this.nom=Miroir;
    }
}
