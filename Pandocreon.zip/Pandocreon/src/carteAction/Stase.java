package carteAction;

public class Stase extends DeusEx{
	//contructeur
    public Stase(String Stase){
   	 this.nom=Stase;
    }
}
