package carteAction;

public class Messie extends GuideSpirituel{
	//contructeur
    public Messie(String Messie){
   	  this.nom=Messie;
    }
}
