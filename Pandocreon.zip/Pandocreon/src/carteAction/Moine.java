package carteAction;

public class Moine extends Croyant{
	//contructeur
    public Moine (String Moine){
   	 this.nom=Moine;
    }
}
