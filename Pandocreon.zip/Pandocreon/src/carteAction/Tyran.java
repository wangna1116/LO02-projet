package carteAction;

public class Tyran extends GuideSpirituel{
	//contructeur
    public Tyran(String Tyran){
   	 this.nom=Tyran;
    }
}
